package dev.kosmx.playerAnim.mixin;

import dev.kosmx.playerAnim.api.PartKey;
import dev.kosmx.playerAnim.api.TransformType;
import dev.kosmx.playerAnim.core.impl.AnimationProcessor;
import dev.kosmx.playerAnim.core.util.Vec3f;
import dev.kosmx.playerAnim.impl.IPlayerAnimationState;
import net.minecraft.class_10426;
import net.minecraft.class_10444;
import net.minecraft.class_1306;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_630;
import net.minecraft.class_7833;
import net.minecraft.class_989;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_989.class)
public class HeldItemMixin {

    @Inject(method = "renderArmWithItem", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/item/ItemStackRenderState;render(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;II)V"))
    private void changeItemLocation(class_10426 renderState, class_10444 itemStackRenderState, class_1306 arm, class_4587 matrices, class_4597 multiBufferSource, int i, CallbackInfo ci) {
        if(renderState instanceof IPlayerAnimationState state) {
            if (state.playerAnimator$getAnimationApplier().isActive()) {
                AnimationProcessor anim = state.playerAnimator$getAnimationApplier();

                Vec3f scale = anim.get3DTransform(arm == class_1306.field_6182 ? PartKey.LEFT_ITEM : PartKey.RIGHT_ITEM, TransformType.SCALE,
                        new Vec3f(class_630.field_37937, class_630.field_37937, class_630.field_37937)
                );
                Vec3f rot = anim.get3DTransform(arm == class_1306.field_6182 ? PartKey.LEFT_ITEM : PartKey.RIGHT_ITEM, TransformType.ROTATION, Vec3f.ZERO);
                Vec3f pos = anim.get3DTransform(arm == class_1306.field_6182 ? PartKey.LEFT_ITEM : PartKey.RIGHT_ITEM, TransformType.POSITION, Vec3f.ZERO).scale(1/16f);

                matrices.method_22905(scale.getX(), scale.getY(), scale.getZ());
                matrices.method_46416(pos.getX(), pos.getY(), pos.getZ());

                matrices.method_22907(class_7833.field_40718.rotation(rot.getZ()));    //roll
                matrices.method_22907(class_7833.field_40716.rotation(rot.getY()));    //pitch
                matrices.method_22907(class_7833.field_40714.rotation(rot.getX()));    //yaw
            }
        }
    }
}

package dev.kosmx.playerAnim.mixin;

import dev.kosmx.playerAnim.api.firstPerson.FirstPersonMode;
import dev.kosmx.playerAnim.impl.IAnimatedPlayer;
import dev.kosmx.playerAnim.impl.IUpperPartHelper;
import dev.kosmx.playerAnim.impl.animation.AnimationApplier;
import net.minecraft.class_10034;
import net.minecraft.class_10197;
import net.minecraft.class_1304;
import net.minecraft.class_310;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_572;
import net.minecraft.class_970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static net.minecraft.class_1304.field_6174;

@Mixin(class_970.class)
public abstract class ArmorFeatureRendererMixin<S extends class_10034, M extends class_572<S>, A extends class_572<S>> extends class_3887<S, M> {

    protected ArmorFeatureRendererMixin(class_3883<S, M> renderLayerParent) {
        super(renderLayerParent);
    }

    @Inject(method = "<init>(Lnet/minecraft/client/renderer/entity/RenderLayerParent;Lnet/minecraft/client/model/HumanoidModel;Lnet/minecraft/client/model/HumanoidModel;Lnet/minecraft/client/renderer/entity/layers/EquipmentLayerRenderer;)V", at = @At("RETURN"))
    private void initInject(class_3883 renderLayerParent, class_572 humanoidModel, class_572 humanoidModel2, class_10197 equipmentLayerRenderer, CallbackInfo ci) {
        ((IUpperPartHelper) this).playerAnimator$setUpperPart(false);
    }

    @Inject(
            method = "setPartVisibility",
            at = @At("HEAD"),
            cancellable = true
    )
    private void modifyArmorVisibility(A humanoidModel, class_1304 equipmentSlot, CallbackInfo ci) {
        AnimationApplier emote = ((IAnimatedPlayer) class_310.method_1551().field_1724).playerAnimator_getAnimation();
        if (emote.isActive() && emote.getFirstPersonMode() == FirstPersonMode.THIRD_PERSON_MODEL && emote.getFirstPersonConfiguration().isShowArmor() && FirstPersonMode.isFirstPersonPass()) {
            humanoidModel.method_2805(false);
            if (equipmentSlot == field_6174) {
                humanoidModel.field_3401.field_3665 = emote.getFirstPersonConfiguration().isShowRightArm();
                humanoidModel.field_27433.field_3665 = emote.getFirstPersonConfiguration().isShowLeftArm();
                humanoidModel.field_3391.field_3665 = false;
            }
            ci.cancel();
        }
    }
}

package dev.kosmx.playerAnim.mixin;

import net.minecraft.class_630;
import net.minecraft.class_9950;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_9950.class)
public interface CapeLayerAccessor {
    @Accessor
    public class_630 getCape();
}

package dev.kosmx.playerAnim.mixin.firstPerson;

import dev.kosmx.playerAnim.api.PartKey;
import dev.kosmx.playerAnim.api.TransformType;
import dev.kosmx.playerAnim.api.firstPerson.FirstPersonConfiguration;
import dev.kosmx.playerAnim.api.firstPerson.FirstPersonMode;
import dev.kosmx.playerAnim.core.impl.AnimationProcessor;
import dev.kosmx.playerAnim.core.util.Vec3f;
import dev.kosmx.playerAnim.impl.IAnimatedPlayer;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_746;
import net.minecraft.class_759;
import net.minecraft.class_811;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_759.class)
public class ItemInHandRendererMixin {
    @Inject(method = "renderHandsWithItems", at = @At("HEAD"), cancellable = true)
    private void disableDefaultItemIfNeeded(float f, class_4587 poseStack, class_4597.class_4598 bufferSource, class_746 localPlayer, int i, CallbackInfo ci) {
        if (localPlayer instanceof IAnimatedPlayer player && (player.playerAnimator_getAnimation().getFirstPersonMode() == FirstPersonMode.THIRD_PERSON_MODEL)) {
                ci.cancel();
            }

    }

    /* AW needed, I may do it later
    @Redirect(method = "renderHandsWithItems", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/ItemInHandRenderer;evaluateWhichHandsToRender(Lnet/minecraft/client/player/LocalPlayer;)Lnet/minecraft/client/renderer/ItemInHandRenderer$HandRenderSelection;"))
    private ItemInHandRenderer.HandRenderSelection selectHandsToRender(LocalPlayer localPlayer) {

        return null;
    }*/

    @Inject(method = "renderItem", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/entity/ItemRenderer;renderStatic(Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/ItemDisplayContext;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;Lnet/minecraft/world/level/Level;III)V"), cancellable = true)
    private void cancelItemRender(class_1309 entity, class_1799 itemStack, class_811 transformType, class_4587 poseStack, class_4597 multiBufferSource, int i, CallbackInfo ci) {
        if (entity != class_310.method_1551().method_1560()) {
            return;
        }
        if (FirstPersonMode.isFirstPersonPass() && entity instanceof IAnimatedPlayer player) {
            var config = player.playerAnimator_getAnimation().getFirstPersonConfiguration();
            if (transformType == class_811.field_4322 || transformType == class_811.field_4320) {
                if (!config.isShowRightItem()) {
                    ci.cancel();
                }
            } else {
                if (!config.isShowLeftItem()) {
                    ci.cancel();
                }
            }
        }
    }

//    @Inject(method = "renderItem", at = @At("HEAD"))
//    void changeItemLocation(
//            LivingEntity livingEntity,
//            ItemStack itemStack,
//            ItemDisplayContext itemDisplayContext,
//            PoseStack poseStack,
//            MultiBufferSource multiBufferSource,
//            int i,
//            CallbackInfo ci
//    ) {
//        if(livingEntity instanceof IAnimatedPlayer player) {
//            if (player.playerAnimator_getAnimation().isActive()) {
//                AnimationProcessor anim = player.playerAnimator_getAnimation();
//
//                final var key = itemDisplayContext.leftHand() ? PartKey.LEFT_ITEM : PartKey.RIGHT_ITEM;
//                Vec3f scale = anim.get3DTransform(key, TransformType.SCALE,
//                        new Vec3f(ModelPart.DEFAULT_SCALE, ModelPart.DEFAULT_SCALE, ModelPart.DEFAULT_SCALE)
//                );
//                Vec3f rot = anim.get3DTransform(key, TransformType.ROTATION, Vec3f.ZERO);
//                Vec3f pos = anim.get3DTransform(key, TransformType.POSITION, Vec3f.ZERO).scale(1/16f);
//
//                poseStack.scale(scale.getX(), scale.getY(), scale.getZ());
//                poseStack.translate(pos.getX(), pos.getY(), pos.getZ());
//
//                poseStack.mulPose(Axis.ZP.rotation(rot.getZ()));    //roll
//                poseStack.mulPose(Axis.YP.rotation(rot.getY()));    //pitch
//                poseStack.mulPose(Axis.XP.rotation(rot.getX()));    //yaw
//            }
//        }
//    }
}
